// Load the AWS SDK for Node.js
var AWS = require('aws-sdk');
// Set the region

//var uuid = require("uuid");

exports.handler = (event, context, callback) => {

// Create the DynamoDB service object
    var ddb = new AWS.DynamoDB({apiVersion: '2012-08-10'});

    console.log("ALOHA");


    var student_id = "012345";
//console.log(student_id);
    var student_name = event.student_name;
    var student_gender = event.student_gender;
    var student_dob = event.student_dob;

    var params = {
        TableName: 'student_list',
        Item: {
            'student_id' : {S: student_id},
            'student_name' : {S: student_name},
            'student_gender' : {S: student_gender},
            'student_dob' : {S: student_dob}
        }
    };


// Call DynamoDB to add the item to the table
    ddb.putItem(params, function(err, data) {
        if (err) {
            console.log("Error", err);
        } else {
            console.log("Success", data);
        }
    });
};
